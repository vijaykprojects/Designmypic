import React, { useState, useRef, useEffect } from "react";
import { 
  Upload, 
  Camera, 
  Download, 
  Share2, 
  RefreshCw, 
  Check, 
  X, 
  Image as ImageIcon, 
  Layers, 
  Palette, 
  ArrowRight,
  ChevronLeft,
  Printer,
  Grid,
  User,
  LogOut,
  Lock,
  Mail,
  Key
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { ReactCompareSlider, ReactCompareSliderImage } from "react-compare-slider";
import { cn } from "./lib/utils";

const BG_COLORS = [
  { name: "Transparent", value: "transparent" },
  { name: "White", value: "#ffffff" },
  { name: "Blue", value: "#3b82f6" },
  { name: "Red", value: "#ef4444" },
  { name: "Green", value: "#22c55e" },
  { name: "Black", value: "#000000" },
];

export default function App() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedBgColor, setSelectedBgColor] = useState("transparent");
  const [viewMode, setViewMode] = useState<"home" | "result" | "print-sheet">("home");
  const [showCamera, setShowCamera] = useState(false);
  const [printCount, setPrintCount] = useState(8);
  const [printSheetImage, setPrintSheetImage] = useState<string | null>(null);
  const [isGeneratingSheet, setIsGeneratingSheet] = useState(false);
  
  // Auth & Usage State
  const [user, setUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem("auth_token"));
  const [usageCount, setUsageCount] = useState<number>(parseInt(localStorage.getItem("usage_count") || "0"));
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);

  useEffect(() => {
    if (token) {
      fetchUser();
    }
  }, [token]);

  const fetchUser = async () => {
    try {
      const response = await fetch("/api/me", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
      } else {
        handleLogout();
      }
    } catch (err) {
      console.error("Failed to fetch user", err);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setIsAuthLoading(true);
    try {
      const endpoint = authMode === "login" ? "/api/login" : "/api/signup";
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(authForm)
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("auth_token", data.token);
        setToken(data.token);
        setUser(data.user);
        setShowAuthModal(false);
      } else {
        setAuthError(data.error);
      }
    } catch (err) {
      setAuthError("Something went wrong");
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("auth_token");
    setToken(null);
    setUser(null);
  };

  const incrementUsage = () => {
    const newCount = usageCount + 1;
    setUsageCount(newCount);
    localStorage.setItem("usage_count", newCount.toString());
  };
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setOriginalImage(event.target?.result as string);
        setProcessedImage(null);
        setViewMode("home");
      };
      reader.readAsDataURL(file);
    }
  };

  const removeBackground = async () => {
    if (!originalImage) return;
    
    if (usageCount >= 3 && !user) {
      setShowAuthModal(true);
      return;
    }

    setIsProcessing(true);
    setError(null);
    
    try {
      // Convert base64 to blob
      const response = await fetch(originalImage);
      const blob = await response.blob();
      
      const formData = new FormData();
      formData.append("image", blob, "image.png");
      
      const res = await fetch("/api/remove-bg", {
        method: "POST",
        body: formData,
      });
      
      if (!res.ok) {
        throw new Error("Failed to remove background. Please check your API key or connection.");
      }
      
      const resultBlob = await res.blob();
      const resultUrl = URL.createObjectURL(resultBlob);
      setProcessedImage(resultUrl);
      setViewMode("result");
      incrementUsage();
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadImage = () => {
    if (!processedImage) return;
    
    const canvas = document.createElement("canvas");
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = processedImage;
    
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      
      if (selectedBgColor !== "transparent") {
        ctx.fillStyle = selectedBgColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      
      ctx.drawImage(img, 0, 0);
      
      const link = document.createElement("a");
      link.download = "clearbg-result.png";
      link.href = canvas.toDataURL("image/png");
      link.click();
    };
  };

  const shareImage = async () => {
    if (!processedImage) return;
    
    try {
      const response = await fetch(processedImage);
      const blob = await response.blob();
      const file = new File([blob], "clearbg-result.png", { type: "image/png" });
      
      if (navigator.share) {
        await navigator.share({
          files: [file],
          title: "ClearBG.Ai Result",
          text: "Check out this background-removed image!",
        });
      } else {
        alert("Sharing is not supported on this browser.");
      }
    } catch (err) {
      console.error("Error sharing:", err);
    }
  };

  const reset = () => {
    setOriginalImage(null);
    setProcessedImage(null);
    setViewMode("home");
    setError(null);
    setPrintSheetImage(null);
  };

  const generatePrintSheet = () => {
    if (!processedImage) return;
    setIsGeneratingSheet(true);

    const canvas = document.createElement("canvas");
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = processedImage;

    img.onload = () => {
      // Standard A4 aspect ratio is ~1.414
      // We'll use a fixed size for high quality
      const pageWidth = 2480; // A4 at 300 DPI
      const pageHeight = 3508;
      canvas.width = pageWidth;
      canvas.height = pageHeight;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Background
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, pageWidth, pageHeight);

      // Calculate grid
      const cols = Math.ceil(Math.sqrt(printCount * (pageWidth / pageHeight)));
      const rows = Math.ceil(printCount / cols);

      const margin = 100;
      const gap = 40;
      const availableWidth = pageWidth - (margin * 2) - (gap * (cols - 1));
      const availableHeight = pageHeight - (margin * 2) - (gap * (rows - 1));

      const cellWidth = availableWidth / cols;
      const cellHeight = availableHeight / rows;

      // Maintain aspect ratio of the image within the cell
      const imgAspectRatio = img.width / img.height;
      let drawWidth = cellWidth;
      let drawHeight = cellWidth / imgAspectRatio;

      if (drawHeight > cellHeight) {
        drawHeight = cellHeight;
        drawWidth = cellHeight * imgAspectRatio;
      }

      for (let i = 0; i < printCount; i++) {
        const col = i % cols;
        const row = Math.floor(i / cols);

        const x = margin + col * (cellWidth + gap) + (cellWidth - drawWidth) / 2;
        const y = margin + row * (cellHeight + gap) + (cellHeight - drawHeight) / 2;

        // Draw background if selected
        if (selectedBgColor !== "transparent") {
          ctx.fillStyle = selectedBgColor;
          ctx.fillRect(x, y, drawWidth, drawHeight);
        }

        ctx.drawImage(img, x, y, drawWidth, drawHeight);
        
        // Optional: Add a thin border for cutting
        ctx.strokeStyle = "#e2e8f0";
        ctx.lineWidth = 2;
        ctx.strokeRect(x, y, drawWidth, drawHeight);
      }

      const sheetUrl = canvas.toDataURL("image/png");
      setPrintSheetImage(sheetUrl);
      setViewMode("print-sheet");
      setIsGeneratingSheet(false);
    };
  };

  const handlePrint = () => {
    if (!printSheetImage) return;
    const win = window.open("");
    if (!win) return;
    win.document.write(`<img src="${printSheetImage}" style="width:100%" onload="window.print();window.close()">`);
    win.document.close();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 text-slate-900 font-sans selection:bg-indigo-200">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/70 backdrop-blur-xl border-b border-slate-200/50 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
            <Layers className="text-white w-6 h-6" />
          </div>
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600 cursor-pointer" onClick={reset}>
            DesignYourPic
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:block text-right">
                <p className="text-xs font-bold text-slate-900">{user.name}</p>
                <p className="text-[10px] text-slate-500">{user.email}</p>
              </div>
              <button 
                onClick={handleLogout}
                className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-600"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button 
              onClick={() => {
                setAuthMode("login");
                setShowAuthModal(true);
              }}
              className="px-4 py-2 bg-slate-900 text-white text-sm font-bold rounded-xl hover:bg-slate-800 transition-all active:scale-95"
            >
              Login
            </button>
          )}
          
          {viewMode === "result" && (
            <button 
              onClick={reset}
              className="p-2 hover:bg-slate-100 rounded-full transition-colors group"
              title="Start Over"
            >
              <RefreshCw className="w-5 h-5 text-slate-600 group-hover:rotate-180 transition-transform duration-500" />
            </button>
          )}
        </div>
      </header>

      <main className="pt-28 pb-12 px-6 max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {viewMode === "home" ? (
            <motion.div 
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-10"
            >
              <div className="text-center space-y-4">
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  className="inline-block px-4 py-1.5 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2"
                >
                  AI Powered Magic
                </motion.div>
                <h2 className="text-4xl font-black tracking-tight text-slate-900 sm:text-5xl leading-tight">
                  Remove Backgrounds <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">Instantly</span>
                </h2>
                <p className="text-slate-500 text-lg max-w-md mx-auto">
                  Upload any photo and watch the background disappear in seconds.
                </p>
              </div>

              {/* Image Preview Area */}
              <div className="relative">
                <motion.div 
                  whileHover={{ y: -5 }}
                  className={cn(
                    "aspect-[4/3] rounded-[2.5rem] border-2 border-dashed transition-all duration-500 flex flex-col items-center justify-center overflow-hidden bg-white shadow-2xl shadow-indigo-100/50",
                    originalImage ? "border-transparent" : "border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/30"
                  )}
                >
                  {originalImage ? (
                    <div className="relative w-full h-full group">
                      <img 
                        src={originalImage} 
                        alt="Original" 
                        className="w-full h-full object-contain"
                      />
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button 
                          onClick={() => setOriginalImage(null)}
                          className="p-4 bg-white rounded-full shadow-xl hover:scale-110 transition-transform"
                        >
                          <X className="w-6 h-6 text-red-500" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center space-y-6 p-8">
                      <div className="w-24 h-24 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-inner">
                        <ImageIcon className="w-12 h-12 text-indigo-500" />
                      </div>
                      <div className="space-y-2">
                        <p className="text-slate-700 font-bold text-xl">Select a photo</p>
                        <p className="text-slate-400 text-sm">Drag and drop or click to browse</p>
                      </div>
                    </div>
                  )}
                </motion.div>
                
                {!originalImage && (
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-full max-w-[80%] bg-white/80 backdrop-blur-md py-3 px-6 rounded-2xl shadow-lg border border-white/50 flex items-center justify-between text-xs font-medium text-slate-500">
                    <span className="flex items-center gap-2"><Check className="w-3 h-3 text-green-500" /> 100% Automatic</span>
                    <span className="flex items-center gap-2"><Check className="w-3 h-3 text-green-500" /> High Quality</span>
                  </div>
                )}
              </div>

              {/* Sample Preview Section */}
              {!originalImage && (
                <div className="space-y-4 pt-4">
                  <p className="text-center text-sm font-bold text-slate-400 uppercase tracking-widest">Try these samples</p>
                  <div className="flex justify-center gap-4">
                    {[
                      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop",
                      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop",
                      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop"
                    ].map((url, i) => (
                      <motion.button
                        key={i}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => setOriginalImage(url)}
                        className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-white shadow-md"
                      >
                        <img src={url} alt="Sample" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center justify-center gap-3 py-5 px-6 bg-white border border-slate-200 rounded-3xl font-bold shadow-sm hover:shadow-xl hover:border-indigo-200 transition-all active:scale-95 group"
                >
                  <Upload className="w-6 h-6 text-indigo-600 group-hover:-translate-y-1 transition-transform" />
                  Gallery
                </button>
                <button 
                  onClick={() => cameraInputRef.current?.click()}
                  className="flex items-center justify-center gap-3 py-5 px-6 bg-white border border-slate-200 rounded-3xl font-bold shadow-sm hover:shadow-xl hover:border-purple-200 transition-all active:scale-95 group"
                >
                  <Camera className="w-6 h-6 text-purple-600 group-hover:-translate-y-1 transition-transform" />
                  Camera
                </button>
              </div>

              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileSelect} 
                accept="image/*" 
                className="hidden" 
              />
              <input 
                type="file" 
                ref={cameraInputRef} 
                onChange={handleFileSelect} 
                accept="image/*" 
                capture="environment" 
                className="hidden" 
              />

              {originalImage && (
                <motion.button
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  onClick={removeBackground}
                  disabled={isProcessing}
                  className={cn(
                    "w-full py-5 px-8 rounded-2xl font-bold text-white shadow-xl shadow-blue-200 flex items-center justify-center gap-3 transition-all active:scale-95",
                    isProcessing ? "bg-slate-400 cursor-not-allowed" : "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  )}
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-6 h-6 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      Remove Background
                      <ArrowRight className="w-6 h-6" />
                    </>
                  )}
                </motion.button>
              )}

              {error && (
                <div className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600">
                  <X className="w-5 h-5 shrink-0" />
                  <p className="text-sm font-medium">{error}</p>
                </div>
              )}
            </motion.div>
          ) : viewMode === "result" ? (
            <motion.div 
              key="result"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setViewMode("home")}
                  className="p-2 hover:bg-white rounded-full transition-colors"
                >
                  <ChevronLeft className="w-6 h-6 text-slate-600" />
                </button>
                <h2 className="text-2xl font-bold text-slate-900">Result</h2>
              </div>

              {/* Comparison Slider */}
              <div className="rounded-3xl overflow-hidden bg-white shadow-2xl border border-white/50">
                <div 
                  className="aspect-[4/3] relative"
                  style={{ backgroundColor: selectedBgColor }}
                >
                  {selectedBgColor === "transparent" && (
                    <div className="absolute inset-0 opacity-10" style={{ 
                      backgroundImage: "radial-gradient(#000 10%, transparent 10%)", 
                      backgroundSize: "10px 10px" 
                    }} />
                  )}
                  
                  <ReactCompareSlider
                    itemOne={<ReactCompareSliderImage src={originalImage!} alt="Original" />}
                    itemTwo={<ReactCompareSliderImage src={processedImage!} alt="Processed" />}
                    className="w-full h-full"
                  />
                  
                  {/* Watermark */}
                  <div className="absolute bottom-4 left-4 px-3 py-1 bg-black/30 backdrop-blur-sm rounded-lg text-[10px] text-white/80 font-medium uppercase tracking-widest pointer-events-none">
                    Made with BG Remover Pro
                  </div>
                </div>
              </div>

              {/* Background Color Picker */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-slate-600 font-semibold">
                  <Palette className="w-5 h-5" />
                  <h3>Replace Background</h3>
                </div>
                <div className="flex flex-wrap gap-3">
                  {BG_COLORS.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedBgColor(color.value)}
                      className={cn(
                        "w-12 h-12 rounded-xl border-2 transition-all flex items-center justify-center relative overflow-hidden",
                        selectedBgColor === color.value ? "border-blue-600 scale-110 shadow-lg shadow-blue-100" : "border-transparent hover:scale-105"
                      )}
                      title={color.name}
                    >
                      {color.value === "transparent" ? (
                        <div className="w-full h-full flex flex-wrap">
                          <div className="w-1/2 h-1/2 bg-slate-200" />
                          <div className="w-1/2 h-1/2 bg-white" />
                          <div className="w-1/2 h-1/2 bg-white" />
                          <div className="w-1/2 h-1/2 bg-slate-200" />
                        </div>
                      ) : (
                        <div className="w-full h-full" style={{ backgroundColor: color.value }} />
                      )}
                      {selectedBgColor === color.value && (
                        <div className="absolute inset-0 flex items-center justify-center bg-blue-600/20">
                          <Check className={cn("w-6 h-6", color.value === "#ffffff" || color.value === "transparent" ? "text-blue-600" : "text-white")} />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Result Actions */}
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={downloadImage}
                  className="flex items-center justify-center gap-2 py-4 px-6 bg-blue-600 text-white rounded-2xl font-bold shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all active:scale-95"
                >
                  <Download className="w-5 h-5" />
                  Download
                </button>
                <button 
                  onClick={shareImage}
                  className="flex items-center justify-center gap-2 py-4 px-6 bg-white border border-slate-200 text-slate-900 rounded-2xl font-bold shadow-sm hover:shadow-md hover:bg-slate-50 transition-all active:scale-95"
                >
                  <Share2 className="w-5 h-5" />
                  Share
                </button>
              </div>

              {/* Print Sheet Feature */}
              <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-xl space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
                    <Grid className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">Create Print Sheet</h3>
                    <p className="text-xs text-slate-500">Multiple photos on one page</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-slate-700">Number of photos</label>
                    <div className="flex items-center gap-3">
                      <button 
                        onClick={() => setPrintCount(Math.max(1, printCount - 1))}
                        className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200 transition-colors"
                      >
                        -
                      </button>
                      <input 
                        type="number" 
                        value={printCount}
                        onChange={(e) => setPrintCount(Math.max(1, parseInt(e.target.value) || 1))}
                        className="w-12 text-center font-bold text-slate-900 bg-transparent outline-none"
                      />
                      <button 
                        onClick={() => setPrintCount(printCount + 1)}
                        className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200 transition-colors"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    {[4, 8, 12, 16, 24].map(num => (
                      <button 
                        key={num}
                        onClick={() => setPrintCount(num)}
                        className={cn(
                          "flex-1 py-2 rounded-xl text-xs font-bold transition-all",
                          printCount === num ? "bg-indigo-600 text-white shadow-md" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                        )}
                      >
                        {num}
                      </button>
                    ))}
                  </div>

                  <button 
                    onClick={generatePrintSheet}
                    disabled={isGeneratingSheet}
                    className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-100 flex items-center justify-center gap-2 hover:shadow-xl transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isGeneratingSheet ? (
                      <RefreshCw className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        <ArrowRight className="w-5 h-5" />
                        Next: Generate Sheet
                      </>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          ) : viewMode === "print-sheet" ? (
            <motion.div 
              key="print-sheet"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-8"
            >
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setViewMode("result")}
                  className="p-2 hover:bg-white rounded-full transition-colors"
                >
                  <ChevronLeft className="w-6 h-6 text-slate-600" />
                </button>
                <h2 className="text-2xl font-bold text-slate-900">Print Sheet</h2>
              </div>

              <div className="bg-white p-4 rounded-3xl shadow-2xl border border-slate-100">
                <div className="aspect-[1/1.414] w-full relative overflow-hidden rounded-xl bg-slate-50 border border-slate-200">
                  {printSheetImage && (
                    <img 
                      src={printSheetImage} 
                      alt="Print Sheet" 
                      className="w-full h-full object-contain"
                    />
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <button 
                  onClick={() => {
                    const link = document.createElement("a");
                    link.download = "print-sheet.png";
                    link.href = printSheetImage!;
                    link.click();
                  }}
                  className="flex items-center justify-center gap-3 py-5 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
                >
                  <Download className="w-6 h-6" />
                  Download Sheet
                </button>
                
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={handlePrint}
                    className="flex items-center justify-center gap-3 py-5 bg-white border border-slate-200 text-slate-900 rounded-2xl font-bold shadow-sm hover:shadow-md transition-all active:scale-95"
                  >
                    <Printer className="w-6 h-6 text-indigo-600" />
                    Print
                  </button>
                  <button 
                    onClick={async () => {
                      try {
                        const response = await fetch(printSheetImage!);
                        const blob = await response.blob();
                        const file = new File([blob], "print-sheet.png", { type: "image/png" });
                        if (navigator.share) {
                          await navigator.share({
                            files: [file],
                            title: "Print Sheet",
                            text: "My photo sheet from DesignYourPic",
                          });
                        }
                      } catch (err) {
                        console.error(err);
                      }
                    }}
                    className="flex items-center justify-center gap-3 py-5 bg-white border border-slate-200 text-slate-900 rounded-2xl font-bold shadow-sm hover:shadow-md transition-all active:scale-95"
                  >
                    <Share2 className="w-6 h-6 text-purple-600" />
                    Share
                  </button>
                </div>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>

        {/* Auth Modal */}
        <AnimatePresence>
          {showAuthModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => !((usageCount >= 3 && !user)) && setShowAuthModal(false)}
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative w-full max-w-md bg-white rounded-[32px] shadow-2xl overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <h2 className="text-2xl font-black text-slate-900">
                        {authMode === "login" ? "Welcome Back" : "Create Account"}
                      </h2>
                      <p className="text-slate-500 text-sm mt-1">
                        {usageCount >= 3 && !user 
                          ? "You've reached the free limit. Please sign in to continue." 
                          : "Sign in to DesignYourPic to access all features."}
                      </p>
                    </div>
                    {!(usageCount >= 3 && !user) && (
                      <button 
                        onClick={() => setShowAuthModal(false)}
                        className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                      >
                        <X className="w-5 h-5 text-slate-400" />
                      </button>
                    )}
                  </div>

                  {authError && (
                    <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 text-sm font-medium">
                      <X className="w-4 h-4" />
                      {authError}
                    </div>
                  )}

                  <form onSubmit={handleAuth} className="space-y-4">
                    {authMode === "signup" && (
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 ml-1 uppercase tracking-wider">Full Name</label>
                        <div className="relative">
                          <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <input 
                            type="text"
                            required
                            placeholder="John Doe"
                            className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                            value={authForm.name}
                            onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })}
                          />
                        </div>
                      </div>
                    )}

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 ml-1 uppercase tracking-wider">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <input 
                          type="email"
                          required
                          placeholder="name@example.com"
                          className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                          value={authForm.email}
                          onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 ml-1 uppercase tracking-wider">Password</label>
                      <div className="relative">
                        <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <input 
                          type="password"
                          required
                          placeholder="••••••••"
                          className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                          value={authForm.password}
                          onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
                        />
                      </div>
                    </div>

                    <button 
                      type="submit"
                      disabled={isAuthLoading}
                      className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold shadow-xl shadow-slate-200 hover:bg-slate-800 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {isAuthLoading ? (
                        <RefreshCw className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          {authMode === "login" ? "Sign In" : "Create Account"}
                          <ArrowRight className="w-5 h-5" />
                        </>
                      )}
                    </button>
                  </form>

                  <div className="mt-8 text-center">
                    <button 
                      onClick={() => setAuthMode(authMode === "login" ? "signup" : "login")}
                      className="text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors"
                    >
                      {authMode === "login" ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
                    </button>
                  </div>
                </div>
                
                {usageCount >= 3 && !user && (
                  <div className="bg-blue-50 p-6 border-t border-blue-100 flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-200 shrink-0">
                      <Lock className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-blue-900">Free Limit Reached</p>
                      <p className="text-xs text-blue-600">Sign up to unlock unlimited background removals.</p>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer info */}
      <footer className="text-center py-12 border-t border-slate-100 bg-white/50 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-6">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200 mb-2">
              <Layers className="text-white w-7 h-7" />
            </div>
            <h2 className="text-2xl font-black tracking-tight text-slate-900">DesignYourPic</h2>
            <p className="text-slate-500 max-w-xs mx-auto">
              The ultimate AI-powered tool for background removal and print sheet generation.
            </p>
            <div className="w-full h-px bg-slate-100 my-4" />
            <p className="text-slate-400 text-sm font-medium">
              © 2026 DesignYourPic. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
